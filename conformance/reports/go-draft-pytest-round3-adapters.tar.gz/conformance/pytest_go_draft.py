"""Full Go Draft plus native artifact rendering; other boundaries stay explicit."""
import pytest_go_combined as combined
import pytest_go_core as core

pytest_collection_modifyitems=combined.pytest_collection_modifyitems
pytest_runtest_logstart=combined.pytest_runtest_logstart
pytest_runtest_logfinish=combined.pytest_runtest_logfinish
pytest_runtest_logreport=combined.pytest_runtest_logreport
pytest_sessionfinish=combined.pytest_sessionfinish

def pytest_configure(config):
    combined.pytest_configure(config)
    import draft_bridge
    draft_bridge.install(core.native_operation,core.cap.plain)
