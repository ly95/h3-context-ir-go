package compiler

import (
	"fmt"
	"regexp"
	"sort"
	"strings"
	"unicode"

	"github.com/ly95/contextir"
)

// GeneratedShotInput explicitly selects a compatibility operation for generated
// template prose. It is never applied to Brief.Intent, literal Document text,
// dialogue words or visible lettering by Compile/Draft. Structured camera and
// dialogue events remain authoritative; no intent, role or permission is inferred.
type GeneratedShotInput struct {
	Shot             contextir.Shot
	Body             string
	Camera           Camera
	DialogueEvents   map[string]contextir.Event // exact template tokens, e.g. {{D1}}
	SubjectTokens    map[string]string          // exact protocol labels -> stable subject IDs
	RequiredSubjects []string
	WordLimit        int
	// TrimSentences explicitly permits removing whole generated sentences above
	// WordLimit. Without this choice overflow is an error, never silent truncation.
	TrimSentences bool
}
type GeneratedShotResult struct {
	Shot  contextir.Shot
	Notes []string
}

var generatedCameraSentence = regexp.MustCompile(`(?i)(?:^|[.!?]\s+)(The camera\b[^.!?]*[.!?]?)`)
var generatedContinuation = regexp.MustCompile(`^\s+[a-z][^.!?]*[.!?]?`)

// PrepareGeneratedShot converts explicitly supplied legacy model placeholders to
// native typed events/spans, with a note for every repair. Regexes recognize only
// output-format camera sentences; they never interpret a user's requested action.
func PrepareGeneratedShot(in GeneratedShotInput) (GeneratedShotResult, error) {
	out := GeneratedShotResult{Shot: in.Shot, Notes: []string{}}
	if in.Shot.ID == "" || in.Shot.End <= in.Shot.Start {
		return out, invalid("shot", "Supply a stable shot ID and increasing boundaries.")
	}
	if !contains(CameraTypes, in.Camera.Type) || !contains([]string{"", "small", "large"}, in.Camera.Amplitude) || !contains([]string{"", "slow", "fast"}, in.Camera.Speed) || in.Camera.Type == "Static Shot" && (in.Camera.Amplitude != "" || in.Camera.Speed != "") {
		return out, invalid("camera", "Supply an exact closed camera type and modifiers.")
	}
	if in.WordLimit < 0 {
		return out, invalid("word_limit", "A generated prose budget cannot be negative.")
	}
	if len(in.Shot.Description) > 0 || len(in.Shot.Events) > 0 {
		return out, invalid("shot", "Pass an empty native body/events; this operation accepts generated template prose explicitly.")
	}
	body := in.Body
	if index := strings.Index(body, "{{CAM}}"); index >= 0 {
		tail := body[index+len("{{CAM}}"):]
		// A lowercase continuation after the token is generated through a slot owned
		// by the canonical event. Only this explicit template continuation is removed.
		if loc := generatedContinuation.FindStringIndex(tail); loc != nil {
			tail = tail[loc[1]:]
			out.Notes = append(out.Notes, "removed continuation through canonical camera token")
		}
		body = body[:index] + tail
		if strings.Contains(body, "{{CAM}}") {
			return out, invalid("body", "The camera placeholder must occur at most once.")
		}
	} else {
		out.Notes = append(out.Notes, "appended omitted canonical camera event")
	}
	for {
		loc := generatedCameraSentence.FindStringSubmatchIndex(body)
		if loc == nil {
			break
		}
		body = body[:loc[2]] + body[loc[3]:]
		out.Notes = append(out.Notes, "removed redundant generated camera sentence")
	}
	keys := make([]string, 0, len(in.DialogueEvents))
	for token := range in.DialogueEvents {
		keys = append(keys, token)
	}
	sort.Strings(keys)
	events := []contextir.Event{{Kind: contextir.EventCamera, Description: contextir.Text(cameraPhrase(in.Camera))}}
	for _, token := range keys {
		event := in.DialogueEvents[token]
		if !strings.HasPrefix(token, "{{D") || !strings.HasSuffix(token, "}}") || event.Kind != contextir.EventDialogue || event.Dialogue == nil || event.Dialogue.LineID == "" {
			return out, invalid("dialogue_events", "Supply explicit dialogue template tokens and typed line events.")
		}
		if strings.Count(body, token) > 1 {
			return out, invalid("body", "A dialogue placeholder cannot repeat.")
		}
		if !strings.Contains(body, token) {
			out.Notes = append(out.Notes, "appended omitted dialogue event "+token)
		}
		body = strings.ReplaceAll(body, token, "")
		events = append(events, event)
	}
	if strings.Contains(body, "{{") || strings.Contains(body, "}}") {
		return out, invalid("body", "Unresolved generated placeholders cannot be published.")
	}
	body = strings.TrimSpace(body)
	if in.WordLimit > 0 && len(strings.Fields(body)) > in.WordLimit {
		if !in.TrimSentences {
			return out, invalid("body", "Generated prose exceeds the explicit word budget; choose a repair or explicit sentence trimming.")
		}
		end, words := 0, 0
		for start, i := 0, 0; i < len(body); i++ {
			if body[i] != '.' && body[i] != '!' && body[i] != '?' {
				continue
			}
			if i+1 < len(body) && !unicode.IsSpace(rune(body[i+1])) {
				continue
			}
			count := len(strings.Fields(body[start : i+1]))
			if words+count > in.WordLimit {
				break
			}
			words += count
			end = i + 1
			start = i + 1
		}
		if end == 0 {
			return out, invalid("body", "No complete generated sentence fits the explicit budget.")
		}
		body = body[:end]
		out.Notes = append(out.Notes, fmt.Sprintf("trimmed generated prose at a complete sentence to %d words", words))
	}
	// Parse only explicitly supplied protocol tokens. Never guess an unlabelled
	// subject from prose; the caller must supply RequiredSubjects for that choice.
	tokens := make([]string, 0, len(in.SubjectTokens))
	for token, id := range in.SubjectTokens {
		if token == "" || id == "" {
			return out, invalid("subject_tokens", "Token bindings must be nonempty.")
		}
		tokens = append(tokens, token)
	}
	sort.Slice(tokens, func(i, j int) bool { return len(tokens[i]) > len(tokens[j]) })
	seen := map[string]bool{}
	var rich contextir.RichText
	for len(body) > 0 {
		pos, key := -1, ""
		for _, token := range tokens {
			if i := strings.Index(body, token); i >= 0 && (pos < 0 || i < pos) {
				pos, key = i, token
			}
		}
		if pos < 0 {
			rich = append(rich, contextir.Span{Text: body})
			break
		}
		if pos > 0 {
			rich = append(rich, contextir.Span{Text: body[:pos]})
		}
		id := in.SubjectTokens[key]
		rich = append(rich, contextir.Span{SubjectID: id})
		seen[id] = true
		body = body[pos+len(key):]
	}
	for _, id := range in.RequiredSubjects {
		if id == "" {
			return out, invalid("required_subjects", "Required subject IDs must be nonempty.")
		}
		if !seen[id] {
			rich = append(rich, contextir.Span{Text: " Visible in the shot is "}, contextir.Span{SubjectID: id}, contextir.Span{Text: "."})
			seen[id] = true
			out.Notes = append(out.Notes, "attached "+id)
		}
	}
	if len(rich) == 0 {
		return out, invalid("body", "Generated shot prose must not be empty after explicit repairs.")
	}
	out.Shot.Description = rich
	out.Shot.Events = events
	return out, nil
}
