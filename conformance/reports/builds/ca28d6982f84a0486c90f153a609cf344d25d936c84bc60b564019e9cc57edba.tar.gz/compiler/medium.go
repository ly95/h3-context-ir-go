package compiler

import (
	"context"
	"encoding/json"
	"sort"
	"strings"

	"github.com/ly95/contextir"
	"github.com/ly95/contextir/planner"
)

var mediumBuckets = []string{"", "2d-animation", "3d-animation", "archival", "stop-motion", "painted", "live-action"}
var treatmentVocabulary = []string{"cinematic", "moody", "high-contrast", "chiaroscuro", "grainy", "soft", "dramatic", "muted", "saturated", "backlit", "neon", "warm", "cold"}

type MediumDecision struct {
	RetainedStyle   string              `json:"retained_style,omitempty"`
	Disposition     string              `json:"disposition"`
	OperationQuote  string              `json:"operation_quote"`
	Target          string              `json:"target"`
	RequestedStyle  string              `json:"requested_style"`
	ReferenceMedium string              `json:"reference_medium"`
	RequestedMedium string              `json:"requested_medium"`
	Treatments      []string            `json:"treatments"`
	Reasoning       string              `json:"reasoning"`
	Calls           []planner.CallUsage `json:"calls,omitempty"`
}

func (c *Compiler) decideMedium(ctx context.Context, b Brief, readings []LicenceReference, visual bool) (MediumDecision, error) {
	var out MediumDecision
	object := func(props map[string]any) map[string]any {
		keys := []string{}
		for key := range props {
			keys = append(keys, key)
		}
		sort.Strings(keys)
		return map[string]any{"type": "object", "additionalProperties": false, "required": keys, "properties": props}
	}
	disposition := map[string]any{"type": "string", "enum": []string{"preserve", "convert"}}
	if !visual {
		disposition = map[string]any{"const": "no_reference"}
	} else if b.Style != "" {
		disposition = map[string]any{"const": "convert"}
	}
	referenceBucket := map[string]any{"type": "string", "enum": mediumBuckets}
	if !visual {
		referenceBucket = map[string]any{"const": ""}
	}
	props := map[string]any{"disposition": disposition, "operation_quote": map[string]any{"type": "string"}, "target": map[string]any{"type": "string"}, "requested_style": map[string]any{"type": "string"}, "reference_medium": referenceBucket, "requested_medium": map[string]any{"type": "string", "enum": mediumBuckets}, "treatments": map[string]any{"type": "array", "items": map[string]any{"type": "string", "enum": treatmentVocabulary}}, "reasoning": map[string]any{"type": "string"}}
	if reading, ok := referenceStyleReading(readings); ok && reading.Card.IsReferenceSheet {
		props["retained_style"] = map[string]any{"type": "string", "minLength": 1}
	}
	schema, _ := json.Marshal(object(props))
	const system = `Resolve one narrow permission before visual writing: may the requested video depart from the attached visual reference's rendering medium? Interpret complete instructions semantically, not from keywords. The reference is the authority unless the caller expressly requests a departure operation or directly instructs that the result be rendered in a target rendition. A syntactically complete instruction that the result be in the style of a particular medium is an explicit target rendition, even without a separate change/reimagine verb. A loose style adjective appended to an action is descriptive, even if incompatible with the reference; it does not authorize changing medium. Distinguish the instruction's grammatical role, rather than requiring a member of a verb list or treating every medium mention as permission.
Motion is a separate dimension: making a still move or bringing its subject to life does not by itself convert its depicted medium. An animated photograph can retain the photograph's live-action appearance. Aspect, duration, creativity and director choices never authorize medium conversion. Explicit structured Brief.style is authoritative, unlike a loose adjective in the intent.
Return disposition preserve when no departure is expressly authorized; operation_quote/target are then empty. For convert, operation_quote must quote the actual departure operation in the user's intent, not just the target medium adjective; target is the complete requested target noun phrase. If structured Brief.style authorizes it, target/requested_style equal that exact value and operation_quote may be empty. With no visual reference use no_reference, empty operation_quote/target/reference_medium, and identify any requested visual style independently. No transformation exists without a source reference.
reference_medium and requested_medium are the supplied semantic taxonomy IDs; unknown is empty. 2d-animation includes flat or digitally drawn illustration, comic/graphic illustration and hand-drawn or cel animation, whether realistic or stylised. painted denotes a work presented as physical painted media, with painterly brushwork/paint surface; it is not a catch-all for every illustrated reference. 3d-animation denotes volumetric computer-rendered animation; stop-motion denotes photographed physical miniature/puppet frame animation. A still illustration may belong to an animation rendering family without making any claim that the attached still itself moves. Use the identified rendering process, not incidental words or whether a drawing is semi-realistic. Reference style comes from the edit-source clip before an incoming replacement/placement portrait, otherwise the first observed image style. Classify that actual observed phrase, never a guessed scene. When the schema includes retained_style, the selected source is a reference sheet: return only its actual rendering medium and stylistic traits, excluding sheet/turnaround/panel/label/contact-sheet/presentation packaging. The requested scene must not be a reference-sheet layout. If the observed style phrase contains no presentation packaging, copy its existing wording exactly; otherwise remove only that packaging, keeping all actual visual style. No invented restyling. Requested medium records even a loose mentioned medium, while disposition independently decides whether it is authorized. requested_style is only the requested medium noun phrase, excluding treatments; if none, leave it empty. Treatments are the supplied compatible treatment vocabulary, in the order the user asks for them; never classify a medium such as anime as a treatment. Return only JSON. Do not invent explicit instructions or scan from a keyword list.`
	var diagnostics []contextir.Issue
	for attempt := 1; attempt <= c.options.MaxStructureRetries+1; attempt++ {
		if ctx.Err() != nil {
			return out, failure(contextir.CodeCanceled, "medium", "context", "Medium permission interpretation was canceled.", ctx.Err())
		}
		input, _ := json.Marshal(map[string]any{"intent": b.Intent, "explicit_style": b.Style, "constraints": b.Constraints, "observed_phrase": observedReferenceStyle(readings, true), "has_visual_reference": visual, "diagnostics": diagnostics})
		response, callErr := c.model.Generate(ctx, contextir.ModelRequest{Stage: "medium", System: system, Input: input, ResponseSchema: append(json.RawMessage(nil), schema...)})
		valid := !response.UsageInvalid && response.Usage.InputTokens >= 0 && response.Usage.OutputTokens >= 0
		out.Calls = append(out.Calls, planner.CallUsage{Stage: "medium", Attempt: attempt, Model: response.Model, Usage: response.Usage, Valid: valid})
		if ctx.Err() != nil {
			return out, failure(contextir.CodeCanceled, "medium", "context", "Medium permission interpretation was canceled.", ctx.Err())
		}
		if callErr != nil && !repairableModelOutput(callErr) {
			return out, failure(contextir.CodeModel, "medium", "model", "Medium permission interpretation failed.", callErr)
		}
		if !valid {
			return out, failure(contextir.CodeModelOutput, "medium", "usage", "Medium permission interpretation returned invalid usage.", callErr)
		}
		if callErr != nil {
			if attempt <= c.options.MaxStructureRetries {
				diagnostics = repairDiagnostics(callErr, "medium", "Return the complete typed medium permission.")
				continue
			}
			return out, failure(contextir.CodeModelOutput, "medium", "model", "Medium permission interpretation failed.", callErr)
		}
		var reply MediumDecision
		err := validateWire(response.JSON, schema)
		if err == nil {
			err = strictDecode(response.JSON, &reply)
		}
		if err == nil && reply.Disposition == "convert" && b.Style == "" && (reply.OperationQuote == "" || reply.Target == "" || !scopeTextContains(b, reply.OperationQuote, nil)) {
			err = invalid("medium.operation_quote", "A conversion requires an exact quote of the caller's departure operation and its complete target.")
		}
		if err == nil && reply.Disposition != "convert" && (reply.OperationQuote != "" || reply.Target != "") {
			err = invalid("medium", "No conversion means no claimed operation or transferred target.")
		}
		if err == nil && b.Style != "" && (reply.Target != b.Style && visual || reply.RequestedStyle != b.Style) {
			err = invalid("medium.target", "Preserve the explicit structured Style exactly.")
		}
		if err == nil {
			calls := out.Calls
			out = reply
			out.Calls = calls
			return out, nil
		}
		diagnostics = repairDiagnostics(err, "medium", "Distinguish descriptive adjectives from an actual authorized departure operation.")
	}
	return out, failure(contextir.CodeModelOutput, "medium", "medium", "Medium permission did not satisfy the typed contract.", nil)
}

// This is deterministic formatting of trusted observation fields, not intent
// inference. It never grants a permission or decides which medium was requested.
func tidyObservedStyle(raw string) string {
	text := strings.TrimRight(strings.TrimSpace(raw), ". ")
	for _, prefix := range []string{"resembling ", "similar to ", "like ", "reminiscent of ", "suggesting "} {
		if strings.HasPrefix(strings.ToLower(text), prefix) {
			text = text[len(prefix):]
			break
		}
	}
	for _, prefix := range []string{"a ", "an ", "the "} {
		if strings.HasPrefix(strings.ToLower(text), prefix) {
			text = text[len(prefix):]
			break
		}
	}
	for _, suffix := range []string{" styles", " style"} {
		if strings.HasSuffix(strings.ToLower(text), suffix) {
			text = text[:len(text)-len(suffix)]
			break
		}
	}
	return text
}
func observedReferenceStyle(readings []LicenceReference, lighting bool) string {
	reading, ok := referenceStyleReading(readings)
	if !ok {
		return ""
	}
	phrase := tidyObservedStyle(reading.Card.Style)
	if lighting && !reading.Card.IsReferenceSheet && reading.Card.Lighting != "" {
		phrase += ", " + lowerInitial(tidyObservedStyle(reading.Card.Lighting))
	}
	return phrase
}
func referenceStyleReading(readings []LicenceReference) (LicenceReference, bool) {
	selected := -1
	for i, reading := range readings {
		if reading.Role == RoleEditSource && reading.Card.Style != "" {
			selected = i
			break
		}
	}
	if selected < 0 {
		for i, reading := range readings {
			if reading.Kind == contextir.MediaImage && reading.Card.Style != "" {
				selected = i
				break
			}
		}
	}
	if selected < 0 {
		return LicenceReference{}, false
	}
	return readings[selected], true
}
func lowerInitial(s string) string {
	for _, r := range s {
		return strings.ToLower(string(r)) + s[len(string(r)):]
	}
	return s
}
func resolvedVisualStyle(b Brief, medium MediumDecision, readings []LicenceReference, governs map[string]string) StyleDecision {
	observed := observedReferenceStyle(readings, governs["lighting"] != "request")
	style := StyleDecision{ReferenceMedium: medium.ReferenceMedium, RequestedMedium: medium.RequestedMedium, ObservedPhrase: observed}
	switch {
	case b.Style != "":
		style.Phrase = b.Style
		style.Source = "request"
	case medium.Disposition == "convert":
		style.Phrase = medium.Target
		style.Source = "request"
	case observed != "":
		style.Phrase = observed
		if medium.RetainedStyle != "" {
			style.Phrase = medium.RetainedStyle
		}
		style.Source = "reference"
	case medium.RequestedStyle != "":
		style.Phrase = medium.RequestedStyle
		style.Source = "request"
	default:
		style.Phrase = "Live-action, cinematic"
		style.Source = "default"
	}
	if b.Style == "" {
		for _, treatment := range medium.Treatments {
			if !strings.Contains(strings.ToLower(style.Phrase), treatment) {
				style.Phrase += ", " + treatment
			}
		}
	}
	style.Discrepancy = style.ReferenceMedium != "" && style.RequestedMedium != "" && style.ReferenceMedium != style.RequestedMedium
	if style.Discrepancy {
		if style.Source == "reference" {
			style.Note = "The request mentions a different rendering medium, but the brief keeps the reference. A loose style adjective does not authorize departure; ask explicitly to reimagine as the desired medium to change it."
		} else {
			style.Note = "The request explicitly changes the rendering medium while retaining the referenced identity; this does not by itself select an attribute-transfer relationship."
		}
	}
	return style
}
